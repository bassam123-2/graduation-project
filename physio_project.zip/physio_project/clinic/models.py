from django.contrib.auth.models import AbstractUser
from django.db import models

# أول شيء نعرف CustomUser
class CustomUser(AbstractUser):
    ROLE_CHOICES = (
        ('patient', 'Patient'),
        ('therapist', 'Therapist'),
        ('admin', 'Admin'),
    )
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default='patient')

    def __str__(self):
        return f"{self.username} ({self.role})"

# بعده نعرف Appointment
class Appointment(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    date = models.DateTimeField()
    note = models.TextField(blank=True)

    def __str__(self):
        return f"{self.user.username} - {self.date}"

# بعده TreatmentPlan
class TreatmentPlan(models.Model):
    appointment = models.ForeignKey(Appointment, on_delete=models.CASCADE)
    plan_details = models.TextField()

    def __str__(self):
        return f"Plan for {self.appointment.user.username}"
